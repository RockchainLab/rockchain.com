$(document).ready(function(){
	//Mobile menu
	$(".mobile-menu__trigger").click(function(){
		$(".mobile-menu").toggleClass("active");
	});
});
